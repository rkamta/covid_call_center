

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div id="demo-bar" users='<?php echo json_encode($data['users'], 15, 512) ?>' user_id='<?php echo json_encode($data['user_id'], 15, 512) ?>' save_url="/api/form/add" edit_mode=0></div>
            <div id="react-form-builder" url="" saveUrl=""></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Covid19\resources\views/forms/add.blade.php ENDPATH**/ ?>