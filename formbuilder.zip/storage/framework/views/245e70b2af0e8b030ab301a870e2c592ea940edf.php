

<?php $__env->startSection('content'); ?>
<div class="page profile" style="background-image: url(<?php echo e(asset('images/profile-bg.png')); ?>)">
    <div class="content-wrapper">
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-12 align-self-center text-center">
                    <h3 class="ribbon-wrapper page-title text-truncate font-weight-medium mb-1 text-white">
                        <div class="ribbon">
                            <strong class="ribbon-inner">Profile</strong>
                        </div>
                    </h3>
                </div>
            </div>
        </div>
        <div class="container-fluid mt-3">
            <div class="row justify-content-center">
                <div class="col-sm-12 col-md-8 offset-auto">
                <div id="react-profile-form-first" data='<?php echo json_encode($data, 15, 512) ?>' action_url='<?php echo e(route('profile-update')); ?>'>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Covid19\resources\views/profile.blade.php ENDPATH**/ ?>