

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div id="forms-table" class="mt-3">
                <table class="table table-border">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Province</th>
                            <th class="text-center">Has Form</th>
                            <th>Active</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->profile); ?></td>

                            <td class="text-center">
                                <?php if($user->formset): ?>
                                <i class="fa fa-check" style="color: green"></i>
                                <?php else: ?>
                                <i class="fa fa-times" style="color: red"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($user->formset): ?>
                                <input type="checkbox" name="active" id="active">
                                <?php else: ?>
                                <i class="fa fa-ban text-muted"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($user->formset): ?>
                                <a class="btn btn-secondary btn-sm mr-1"
                                    href="<?php echo e(route('formset-edit', $user->formset->id)); ?>"><i
                                        class="fa fa-edit"></i></a>
                                <button class="btn btn-warning btn-sm"
                                    onclick="delFormSet('<?php echo e(route('formset-delete', $user->formset->uuid)); ?>')"><i
                                        class="fa fa-trash"></i></button>
                                <?php else: ?>
                                <a class="btn btn-primary btn-sm mr-1"
                                    href="<?php echo e(route('formset-user-add', $user->id)); ?>"><i class="fa fa-plus"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_script'); ?>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<script>
    function delFormSet(url) {
        if(confirm('Sure?')) {
            window.location.href = url;
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Covid19\resources\views/forms/list.blade.php ENDPATH**/ ?>