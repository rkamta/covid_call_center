export default { CARD: 'card' };
