

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <script>
                var FORM_ACTION = "/testing";
                var FORM_METHOD = "POST";
            </script>
            <div id="demo-bar"></div>
            <div id="react-form-builder"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Covid19\resources\views/profile.blade.php ENDPATH**/ ?>